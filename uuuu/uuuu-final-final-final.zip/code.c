#include <anything.h>

int main()
{
	do_something();
	return 0;
}